# import
library(caret)
library(dplyr)
library(doParallel)

wifiData <- read.csv('UJIndoorLoc/trainingData.csv')

# pre-processing
wifiData <- cbind(wifiData, paste(wifiData$FLOOR, wifiData$BUILDINGID, wifiData$SPACEID, wifiData$RELATIVEPOSITION), stringsAsFactors = TRUE)

colnames(wifiData)[1] <- 'F_B_S_R'

wifiData <- wifiData %>% select('F_B_S_R', everything()) # move new column to the front

head(wifiData)

str(wifiData) # check data type -> F_B_S_R has 905 levels

wifiDataRM <- wifiData[-c(2:4, 6:10)] # remove features that are not WAP, keep buildingID

head(wifiDataRM)

str(wifiDataRM) # 905 levels

building0 <- filter(wifiDataRM, BUILDINGID == 0)
building1 <- filter(wifiDataRM, BUILDINGID == 1)
building2 <- filter(wifiDataRM, BUILDINGID == 2)

building0$BUILDINGID <- NULL # remove buildingID
building1$BUILDINGID <- NULL
building2$BUILDINGID <- NULL

building2$F_B_S_R <- droplevels(building2$F_B_S_R)

str(building2) # factor change to 403 levels

# nearZeroVar -> remove zero variance features
nzv <- nearZeroVar(building2, saveMetrics= TRUE)
head(nzv) # look for TRUE in zeroVar column
summary(nzv) # TRUE 317 FALSE 204

zeroVarData <- which(nzv$zeroVar == T)
zeroVarData # show index 

building2new <- building2[, -(zeroVarData)] # remove zero variance WAP

str(building2new$F_B_S_R) # check dependant

# assign cores
detectCores() # find cores no. -> 8

cl <- makeCluster(3) # decide how many clusters to use. do not use all

registerDoParallel(cl) # register

getDoParWorkers() # confirm assgined core numbers

stopCluster(cl) # end cluster. do this after work is done

# 3 models C5.0, KNN, RF
set.seed(123)

# create test/train set           dataframe$dependent
inTraining <- createDataPartition(building2new$F_B_S_R, p = 0.80, list = FALSE)
training <- building2new[inTraining,]
testing <- building2new[-inTraining,]

# 10-fold cross-validation and automatic tuning
fitControl <- trainControl(method = 'repeatedcv', number = 10, repeats = 1)

# modeling with c5.0
c5.0Fit <- train(F_B_S_R~., data = training, method = 'C5.0', trControl = fitControl, tuneLength = 5)

c5.0Fit # optimal model trials = 30, model = rules, winnow = false # accuracy 72.23 kappa 72.14 process time ~20 mins

varImp(c5.0Fit)

# modeling with knn
knnFit <- train(F_B_S_R~., data = training, method = 'knn', trControl = fitControl, tuneLength = 5)

knnFit # optimal k = 5, accuracy 61.83 kappa 61.71 process time ~5 mins

# modeling with random forest
rfFit <- train(F_B_S_R~., data = training, method = 'rf', trControl = fitControl, tuneLength = 5)

rfFit # optimal mtry = 52, accuracy 82.11 kappa 82.06, process time ~40 mins


