# import
library(corrplot)
library(caret)
library(gbm)

# dataframe
existingProduct <- read_csv("productattributes/existingproductattributes2017.csv")

# pre-processing - dummify
dumExistingProduct <- dummyVars('~.', data = existingProduct)
existingProductDum <- data.frame(predict(dumExistingProduct, newdata = existingProduct))

# pre-processing - remove missing data
str(existingProductDum)
summary(existingProductDum)
existingProductDum$BestSellersRank <- NULL

# pre-processing - correlation
corrData <- cor(existingProductDum)
corrData
corrplot(corrData)

# PARAMETRIC

# test train split
set.seed(123)

trainSize <- round(nrow(existingProductDum)*0.7)
testSize <- nrow(existingProductDum) - trainSize

trainingIndices <- sample(seq_len(nrow(existingProductDum)), size = trainSize)

trainSet <- existingProductDum[trainingIndices,]
testSet <- existingProductDum[-trainingIndices,]

# train
lmFit1 <- lm(Volume ~ . - ProductNum - ProfitMargin, trainSet)

summary(lmFit1)

sqrt(mean(lmFit1$residuals^2)) # RMSE = 2.465003e-13

# NON PARAMETRIC w/ caret
set.seed(123)

inTraining <- createDataPartition(existingProductDum$Volume, p = 0.80, list = FALSE)
training <- existingProductDum[inTraining,]
testing <- existingProductDum[-inTraining,]

# 10-fold cross-validation and Automatic Tuning Grid
fitControl <- trainControl(method = 'repeatedcv', number = 10, repeats = 1)

# modeling with svm, rf and gbm
svmFit1 <- train(Volume~. - ProductNum - ProfitMargin, data = training, method = 'svmLinear2', trControl = fitControl)

svmFit1

rfFit1 <- train(Volume~. - ProductNum - ProfitMargin, data = training, method = 'rf', trControl = fitControl, tuneLength = 5)

rfFit1

gbmFit1 <- train(Volume~. - ProductNum - ProfitMargin, data = training, method = 'gbm', trControl = fitControl, tuneLength = 5)

gbmFit1

# predict
testPredsvm <- predict(svmFit1, testing)
testPredrf <- predict(rfFit1, testing)
testPredgbm <- predict(gbmFit1, testing)

postResample(testPredsvm, testing$Volume) # postResample show RMSE between prediction and ground truth
postResample(testPredrf, testing$Volume)
postResample(testPredgbm, testing$Volume)

testPredsvm
testPredrf
testPredgbm

# import new data
newProduct <- read.csv("productattributes/newproductattributes2017.csv")

# pre-processing - dummify
dumNewProduct <- dummyVars('~.', data = newProduct)
newProductDum <- data.frame(predict(dumNewProduct, newdata = newProduct))

# pre-processing - remove missing data
str(newProductDum)
summary(newProductDum)
newProductDum$BestSellersRank <- NULL

# predict
testPredNewProductrf <- predict(rfFit1, newProductDum)
postResample(testPredNewProductrf, newProductDum$Volume)

testPredNewProductrf

# add predicitons to csv file
output <- newProduct # copy new product file
output$predictions <- testPredNewProductrf # add predictions to new column 'predictions'

write.csv(output, file = 'C3T3_output.csv', row.names = TRUE) # export file 'output'


