# import and seed
library(caret)
library(gbm)
library(C50)
set.seed(123)

CompleteResponses <- read.csv("SurveyData/CompleteResponses.csv")
surveyIncomplete <- read.csv("SurveyData/SurveyIncomplete.csv")

# EDA
summary(CompleteResponses)
str(CompleteResponses)
names(CompleteResponses)

# pre-processing
CompleteResponses$brand <- as.factor(CompleteResponses$brand)
surveyIncomplete$brand <- as.factor(surveyIncomplete$brand)
str(CompleteResponses)

# create test/train set           dataframe$dependent
inTraining <- createDataPartition(CompleteResponses$brand, p = 0.75, list = FALSE)
training <- CompleteResponses[inTraining,]
testing <- CompleteResponses[-inTraining,]

# 10-fold cross-validation and Automatic Tuning Grid
fitControl <- trainControl(method = 'repeatedcv', number = 10, repeats = 1)

# modeling with gbm and autogrid
gbmFit <- train(brand~., data = training, method = 'gbm', trControl = fitControl, tuneLength = 5)

gbmFit # will run 50 times 10x5

# optimal model interaction.depth = 4,
#               n.trees = 200, 
#               shrinkage = 0.1, 
#               n.minobsinnode = 10

varImp(gbmFit) # need to import gbm to use varImp

# modeling with c5.0 and autogrid
c5.0Fit <- train(brand~., data = training, method = 'C5.0', trControl = fitControl, tuneLength = 5)

c5.0Fit # model = tree, winnow = TRUE, trials = 10

varImp(c5.0Fit)

# modeling with rf and manual grid
rfGrid <- expand.grid(mtry = c(1,2,3,4,5))
rfFit <- train(brand~., data = training, method = 'rf', trControl = fitControl, tuneGrid = rfGrid)

rfFit

varImp(rfFit)

# gbmFit and rfFit show similar result where car, zipcode and elevel is less important

# predict
testPredgbm <- predict(gbmFit, testing)
testPredrf <- predict(rfFit, testing)
testPredc50 <- predict(c5.0Fit, testing)

postResample(testPredgbm, testing$brand) # postResample show accuracy between prediction and ground truth
postResample(testPredrf, testing$brand)
postResample(testPredc50, testing$brand)
           # gbm accuracy 0.9288 kappa 0.850
           # rf accuracy 0.9264 kappa 0.844
           # c50 accuracy 0.9208 kappa 0.833
confusionMatrix(testPredgbm, testing$brand) # confusionMatrix only works on classification
confusionMatrix(testPredrf, testing$brand) # show more information than postResample
confusionMatrix(testPredc50, testing$brand)

# predict with surveyincomplete
testPredgbmSurIn <- predict(gbmFit, surveyIncomplete)
postResample(testPredgbmSurIn, surveyIncomplete$brand)

testPredgbmSurIn

summary(testPredgbm) # 0 980, 1 1494
summary(testPredgbmSurIn) # 0 1946, 1 3054

# removing unimportant features
modifiedCompleteR <- CompleteResponses[, -c(3,5)] # elevel & zipcode
modifiedCompleteR$brand <- as.factor(modifiedCompleteR$brand)
str(modifiedCompleteR)


# second test/train split
inTraining2 <- createDataPartition(modifiedCompleteR$brand, p = 0.75, list = FALSE)
training2 <- modifiedCompleteR[inTraining2,]
testing2 <- modifiedCompleteR[-inTraining2,]

# modeling
gbmFit2 <- train(brand~., data = training2, method = 'gbm', trControl = fitControl, tuneLength = 5)
rfFit2 <- train(brand~., data = training2, method = 'rf', trControl = fitControl, tuneGrid = rfGrid)
c5.0Fit2 <- train(brand~., data = training2, method = 'C5.0', trControl = fitControl, tuneLength = 5)

gbmFit2 # n.trees = 200, interaction.depth = 3
rfFit2 # mtry = 1
c5.0Fit2 # model = tree, winnow = TRUE, trials = 10

varImp(gbmFit2) 
varImp(rfFit2)
varImp(c5.0Fit2)

# predict
testPredgbm2 <- predict(gbmFit2, testing2)
testPredrf2 <- predict(rfFit2, testing2)
testPredc50.2 <- predict(c5.0Fit2, testing2)

postResample(testPredgbm2, testing2$brand) # gbm accuracy 0.9191 kappa 0.830
postResample(testPredrf2, testing2$brand) # rf accuracy 0.9150 kappa 0.823
postResample(testPredc50.2, testing2$brand) # c50 accuracy 0.9208 kappa 0.833

confusionMatrix(testPredgbm2, testing2$brand)
confusionMatrix(testPredrf2, testing2$brand) 
confusionMatrix(testPredc50.2, testing2$brand)

# predict with surveyincomplete
testPredgbmSurIn2 <- predict(c5.0Fit2, surveyIncomplete)

testPredgbmSurIn2

summary(testPredc50.2) # 0 966, 1 1508
summary(testPredgbmSurIn2) # 0 1928, 1 3072
