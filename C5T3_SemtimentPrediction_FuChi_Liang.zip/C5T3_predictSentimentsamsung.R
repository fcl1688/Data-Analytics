# import
library(doParallel)
library(plotly)
library(corrplot)
library(caret)
library(C50)
library(e1071)
library(kknn)

# find out core numbers
detectCores() # 8 cores

cl <- makeCluster(4)
registerDoParallel(cl)

getDoParWorkers() # 4 cores assigned

# stop cluster. do this after finish work
stopCluster(cl)

# iphone small matrix
samsungData <- read.csv("smallmatrix_labeled_8d/galaxy_smallmatrix_labeled_9d.csv")

# preprocessing
samsungData$galaxysentiment <- as.factor(samsungData$galaxysentiment)
samsungData$galaxysentiment <- as.integer(samsungData$galaxysentiment) # used for correlation

str(samsungData)
summary(samsungData)
is.na(samsungData) # no missing value

plot_ly(samsungData, x= ~samsungData$galaxysentiment, type='histogram') # 0: 1696, 1: 382, 2: 450, 3: 1175, 4: 1417, 5: 7791

# feature selection - correlation
options(max.print=1000000)
corrsamsung <- cor(samsungData)
corrplot(corrsamsung)

samsungCOR <- samsungData
samsungCOR <- subset(samsungCOR, select = -c(iphone, nokialumina, htcphone, ios, googleandroid, iphonecampos, sonycampos, nokiacampos,
                                             sonycamneg, nokiacamneg, iphonecamunc, sonycamunc, nokiacamunc, iphonedispos, sonydispos, 
                                             nokiadispos, htcdispos)) # first remove, 42
samsungCOR <- subset(samsungCOR, select = -c(iphonedisneg, sonydisneg, nokiadisneg, iphonedisunc, samsungdisunc, sonydisunc, nokiadisunc,
                                             iphoneperpos, samsungperpos, sonyperpos, nokiaperpos, iphoneperneg, sonyperneg, nokiaperneg,
                                             iphoneperunc, samsungperunc, sonyperunc, nokiaperunc, iosperpos)) # second remove, 23
samsungCOR <- subset(samsungCOR, select = -c(iosperneg, iosperunc, googleperunc)) # third remove, 20

cor(samsungCOR) # every feature below 0.1 is removed

# feature selection - nearzerovar
nzvMetricssamsung <- nearZeroVar(samsungData, saveMetrics = TRUE)
nzvMetricssamsung

nzvsamsung <- nearZeroVar(samsungData, saveMetrics = FALSE) 
nzvsamsung # index of true, 47

samsungNZV <- samsungData[,-nzvsamsung]
str(samsungNZV)

# feature selection - recursive
set.seed(123)
samsungSample <- samsungData[sample(1:nrow(samsungData), 1000, replace=FALSE),]
str(samsungSample)

ctrl <- rfeControl(functions = rfFuncs, method = "repeatedcv", repeats = 5, verbose = FALSE) # rfeControl w/ random forest

rfeResultssamsung <- rfe(samsungSample[,1:58], samsungSample$galaxysentiment, sizes=(1:58), rfeControl=ctrl) # 59 not included ~46mins 3 cores, ~21mins 4 cores
rfeResultssamsung

plot(rfeResultssamsung, type=c("g", "o"))

samsungRFE <- samsungData[,predictors(rfeResultssamsung)]

samsungRFE$galaxysentiment <- samsungData$galaxysentiment # add dependent variable

str(samsungRFE)

# preprocessing for modeling
set.seed(123)
samsungSample2 <- samsungData[sample(1:nrow(samsungData), 4500, replace=FALSE),]

inTrainingsamsung <- createDataPartition(samsungSample2$galaxysentiment, p = 0.70, list = FALSE)
trainingsamsung <- samsungSample2[inTrainingsamsung,]
testingsamsung <- samsungSample2[-inTrainingsamsung,]

fitControl <- trainControl(method = 'repeatedcv', number = 10, repeats = 1)

# modeling - c5.0
c5.0Fit2 <- train(galaxysentiment~., data = trainingsamsung, method = 'C5.0', trControl = fitControl, tuneLength = 5)

c5.0Fit2 # model = tree, winnow = FALSE, trials = 1, accuracy 0.7633, kappa 0.5154 ~less than 1min

# modeling - rf
rfFit2 <- train(galaxysentiment~., data = trainingsamsung, method = 'rf', trControl = fitControl, tuneLength = 5)

rfFit2 # mtry 16, accuracy 0.7684, kappa 0.5287 ~

# modeling - svm
svmFit2 <- train(galaxysentiment~., data = trainingsamsung, method = 'svmLinear2', trControl = fitControl, tuneLength = 5)

svmFit2 # cost = 4, accuracy 0.7141, kappa 0.3862 ~1min

# modeling - kknn
kknnFit2 <- train(galaxysentiment~., data = trainingsamsung, method = 'kknn', trControl = fitControl, tuneLength = 5)

kknnFit2 # kmax = 13, distance = 2, kernel = optimal, accuracy 0.7592, kappa 0.5098 ~less than 1min

# predict
testPredc5.02 <- predict(c5.0Fit2, testingsamsung)
testPredrf2 <- predict(rfFit2, testingsamsung)
testPredsvm2 <- predict(svmFit2, testingsamsung)
testPredkknn2 <- predict(kknnFit2, testingsamsung)

postResample(testPredc5.02, testingsamsung$galaxysentiment) # c5.0 accuracy 0.7670 kappa 0.5233
postResample(testPredrf2, testingsamsung$galaxysentiment) # rf accuracy 0.7841 kappa 0.5616
postResample(testPredsvm2, testingsamsung$galaxysentiment) # svm accuracy 0.7136 kappa 0.3917
postResample(testPredkknn2, testingsamsung$galaxysentiment) # kknn accuracy 0.7640 kappa 0.5192

confusionMatrix(testPredc5.02, testingsamsung$galaxysentiment)
confusionMatrix(testPredrf2, testingsamsung$galaxysentiment) 
confusionMatrix(testPredsvm2, testingsamsung$galaxysentiment)
confusionMatrix(testPredkknn2, testingsamsung$galaxysentiment)

# COR modeling preprocessing
samsungCOR$galaxysentiment <- as.factor(samsungCOR$galaxysentiment)
samsungCOR <- subset(samsungCOR, select = -c(iphonesentiment))
str(samsungCOR)

set.seed(123)
samsungSampleCOR <- samsungCOR[sample(1:nrow(samsungCOR), 4500, replace=FALSE),]

inTrainingCORsamsung <- createDataPartition(samsungSampleCOR$galaxysentiment, p = 0.70, list = FALSE)
trainingCORsamsung <- samsungSampleCOR[inTrainingCORsamsung,]
testingCORsamsung <- samsungSampleCOR[-inTrainingCORsamsung,]

# COR modeling - c5.0
c5.0FitCOR2 <- train(galaxysentiment~., data = trainingCORsamsung, method = 'C5.0', trControl = fitControl, tuneLength = 5)

c5.0FitCOR2 # model = tree, winnow = FALSE, trials = 1, accuracy 0.6675, kappa 0.2515 ~less than 1min

# COR modeling - rf
rfFitCOR2 <- train(galaxysentiment~., data = trainingCORsamsung, method = 'rf', trControl = fitControl, tuneLength = 5)

rfFitCOR2 # mtry 10, accuracy 0.6856, kappa 0.3002 ~1min

# COR modeling - kknn
kknnFitCOR2 <- train(galaxysentiment~., data = trainingCORsamsung, method = 'kknn', trControl = fitControl, tuneLength = 5)

kknnFitCOR2 # kmax = 13, distance = 2, kernel = optimal, accuracy 0.6798, kappa 0.2921 ~less than 1min

# COR predict
testPredkknnCOR2 <- predict(kknnFitCOR2, testingCORsamsung)
testPredrfCOR2 <- predict(rfFitCOR2, testingCORsamsung)

postResample(testPredkknnCOR2, testingCORsamsung$galaxysentiment) # kknn accuracy 0.6839 kappa 0.2950
postResample(testPredrfCOR2, testingCORsamsung$galaxysentiment) # rf accuracy 0.6884 kappa 0.3040

confusionMatrix(testPredkknnCOR2, testingCORsamsung$galaxysentiment)
confusionMatrix(testPredrfCOR2, testingCORsamsung$galaxysentiment) 

# NZV modeling preprocessing
set.seed(123)
samsungSampleNZV <- samsungNZV[sample(1:nrow(samsungNZV), 4500, replace=FALSE),]

inTrainingNZVsamsung <- createDataPartition(samsungSampleNZV$galaxysentiment, p = 0.70, list = FALSE)
trainingNZVsamsung <- samsungSampleNZV[inTrainingNZVsamsung,]
testingNZVsamsung <- samsungSampleNZV[-inTrainingNZVsamsung,]

# NZV modeling - kknn
kknnFitNZV2 <- train(galaxysentiment~., data = trainingNZVsamsung, method = 'C5.0', trControl = fitControl, tuneLength = 5)

kknnFitNZV2 # model = tree, winnow = FALSE, trials = 1, accuracy 0.7493, kappa 0.4769 ~less than 1min

# NZV modeling - rf
rfFitNZV2 <- train(galaxysentiment~., data = trainingNZVsamsung, method = 'rf', trControl = fitControl, tuneLength = 5)

rfFitNZV2 # mtry 2, accuracy 0.7525, kappa 0.4830 ~1min

# NZV predict
testPredkknnNZV2 <- predict(kknnFitNZV2, testingNZVsamsung)
testPredrfNZV2 <- predict(rfFitNZV2, testingNZVsamsung)

postResample(testPredkknnNZV2, testingNZVsamsung$galaxysentiment) # kknn accuracy 0.7433 kappa 0.4696
postResample(testPredrfNZV2, testingNZVsamsung$galaxysentiment) # rf accuracy 0.7492 kappa 0.4770

confusionMatrix(testPredkknnNZV2, testingNZVsamsung$galaxysentiment)
confusionMatrix(testPredrfNZV2, testingNZVsamsung$galaxysentiment) 

# RFE modeling preprocessing
set.seed(123)
samsungSampleRFE <- samsungRFE[sample(1:nrow(samsungRFE), 4500, replace=FALSE),]

inTrainingRFEsamsung <- createDataPartition(samsungSampleRFE$galaxysentiment, p = 0.70, list = FALSE)
trainingRFEsamsung <- samsungSampleRFE[inTrainingRFEsamsung,]
testingRFEsamsung <- samsungSampleRFE[-inTrainingRFEsamsung,]

# RFE modeling - kknn
kknnFitRFE2 <- train(galaxysentiment~., data = trainingRFEsamsung, method = 'C5.0', trControl = fitControl, tuneLength = 5)

kknnFitRFE2 # model = tree, winnow = FALSE, trials = 1, accuracy 0.7649, kappa 0.5171 ~less than 1min

# RFE modeling - rf
rfFitRFE2 <- train(galaxysentiment~., data = trainingRFEsamsung, method = 'rf', trControl = fitControl, tuneLength = 5)

rfFitRFE2 # mtry 7, accuracy 0.7687, kappa 0.5276 ~1min

# RFE predict
testPredkknnRFE2 <- predict(kknnFitRFE2, testingRFEsamsung)
testPredrfRFE2 <- predict(rfFitRFE2, testingRFEsamsung)

postResample(testPredkknnRFE2, testingRFEsamsung$galaxysentiment) # kknn accuracy 0.7589 kappa 0.5064
postResample(testPredrfRFE2, testingRFEsamsung$galaxysentiment) # rf accuracy 0.7663 kappa 0.5250

confusionMatrix(testPredkknnRFE2, testingRFEsamsung$galaxysentiment)
confusionMatrix(testPredrfRFE2, testingRFEsamsung$galaxysentiment)

# import large matrix
samsungLargeMatrix <- read.csv("samsungLargeMatrix.csv")
colnames(samsungRFE)
colnames(samsungLargeMatrix)

samsungLargeRFE <- subset(samsungLargeMatrix, select = c(iphone, samsunggalaxy, googleandroid, htcphone, iphonedisunc, sonyxperia,
                                                         iphonedispos, iphoneperpos, ios, iphoneperneg, iphonecampos, htcdispos,
                                                         iphonedisneg, iphonecamunc, iphoneperunc, htccampos, iphonecamneg, htcperneg, 
                                                         htcperpos, samsungcamunc, htcdisneg, samsungcampos, samsungcamneg, samsungperneg,
                                                         htccamneg, galaxysentiment))
# predict large matrix
samsungSentimentPre <- predict(rfFitRFE2, samsungLargeRFE)
samsungSentimentPre2 <- predict(rfFitRFE2, samsungLargeMatrix)

samsungSentimentPre
samsungSentimentPre2

summary(samsungSentimentPre) # 0 18441, 1 0, 2 762, 3 655, 4 11, 5 5206
summary(samsungSentimentPre2)