# import
library(doParallel)
library(plotly)
library(corrplot)
library(caret)
library(C50)
library(e1071)
library(kknn)

# find out core numbers
detectCores() # 8 cores

cl <- makeCluster(4)
registerDoParallel(cl)

getDoParWorkers() # 4 cores assigned

# stop cluster. do this after finish work
stopCluster(cl)

# iphone small matrix
iphoneData <- read.csv("smallmatrix_labeled_8d/iphone_smallmatrix_labeled_8d.csv")

# preprocessing
iphoneData$iphonesentiment <- as.factor(iphoneData$iphonesentiment)

str(iphoneData)
summary(iphoneData)
is.na(iphoneData) # no missing value

plot_ly(iphoneData, x= ~iphoneData$iphonesentiment, type='histogram') # 0: 1962, 1: 390, 2: 454, 3: 1188, 4: 1439, 5: 7540

# feature selection - correlation
options(max.print=1000000)
corriphone <- cor(iphoneData)
corrplot(corriphone)

iphoneCOR <- iphoneData
iphoneCOR <- subset(iphoneCOR, select = -c(htcphone, ios, iphonecamunc, iphonedisneg, nokiadisunc, iphoneperneg, sonyperneg, iosperpos, iosperneg)) # first remove, 50
iphoneCOR <- subset(iphoneCOR, select = -c(iphone, nokialumina, iphonecampos, sonycampos, nokiacampos, iphonecamneg, sonycamneg, nokiacamneg, 
                                           sonycamunc, nokiacamunc, iphonedispos)) # second remove, 39
iphoneCOR <- subset(iphoneCOR, select = -c(sonydispos, nokiadispos, htcdispos, sonydisneg, nokiadisneg, iphonedisunc, samsungdisunc, sonydisunc, 
                                           iphoneperpos, samsungperpos, sonyperpos, nokiaperpos, samsungperneg)) # third remove, 26
iphoneCOR <- subset(iphoneCOR, select = -c(iphoneperunc, samsungperunc, sonyperunc, nokiaperunc, iosperunc, googleperunc)) # fourth remove, 20

cor(iphoneCOR) # every feature below 0.1 is removed

# feature selection - nearzerovar
nzvMetricsiphone <- nearZeroVar(iphoneData, saveMetrics = TRUE)
nzvMetricsiphone

nzviphone <- nearZeroVar(iphoneData, saveMetrics = FALSE) 
nzviphone # index of true, 47

iphoneNZV <- iphoneData[,-nzviphone]
str(iphoneNZV)

# feature selection - recursive
set.seed(123)
iphoneSample <- iphoneData[sample(1:nrow(iphoneData), 1000, replace=FALSE),]
str(iphoneSample)

ctrl <- rfeControl(functions = rfFuncs, method = "repeatedcv", repeats = 5, verbose = FALSE) # rfeControl w/ random forest

rfeResults <- rfe(iphoneSample[,1:58], iphoneSample$iphonesentiment, sizes=(1:58), rfeControl=ctrl) # 59 not included ~46mins 3 cores, ~21mins 4 cores
rfeResults

plot(rfeResults, type=c("g", "o"))

iphoneRFE <- iphoneData[,predictors(rfeResults)]

iphoneRFE$iphonesentiment <- iphoneData$iphonesentiment # add dependent variable

str(iphoneRFE)

# preprocessing for modeling
set.seed(123)
iphoneSample2 <- iphoneData[sample(1:nrow(iphoneData), 4500, replace=FALSE),]

inTraining <- createDataPartition(iphoneSample2$iphonesentiment, p = 0.70, list = FALSE)
training <- iphoneSample2[inTraining,]
testing <- iphoneSample2[-inTraining,]

fitControl <- trainControl(method = 'repeatedcv', number = 10, repeats = 1)

# modeling - c5.0
c5.0Fit <- train(iphonesentiment~., data = training, method = 'C5.0', trControl = fitControl, tuneLength = 5)

c5.0Fit # model = rules, winnow = FALSE, trials = 1, accuracy 0.7525, kappa 0.5118 ~less than 1min

# modeling - rf
rfFit <- train(iphonesentiment~., data = training, method = 'rf', trControl = fitControl, tuneLength = 5)

rfFit # mtry 16, accuracy 0.7608, kappa 0.5286 ~

# modeling - svm
svmFit <- train(iphonesentiment~., data = training, method = 'svmLinear2', trControl = fitControl, tuneLength = 5)

svmFit # cost = 0.5, accuracy 0.6822, kappa 0.3478 ~1min

# modeling - kknn
kknnFit <- train(iphonesentiment~., data = training, method = 'kknn', trControl = fitControl, tuneLength = 5)

kknnFit # model = kmax, distance = 2, kernel = optimal, accuracy 0.5001, kappa 0.2850 ~less than 1min

# predict
testPredc5.0 <- predict(c5.0Fit, testing)
testPredrf <- predict(rfFit, testing)
testPredsvm <- predict(svmFit, testing)
testPredkknn <- predict(kknnFit, testing)

postResample(testPredc5.0, testing$iphonesentiment) # c5.0 accuracy 0.7802 kappa 0.5721
postResample(testPredrf, testing$iphonesentiment) # rf accuracy 0.7839 kappa 0.5830
postResample(testPredsvm, testing$iphonesentiment) # svm accuracy 0.6881 kappa 0.3599
postResample(testPredkknn, testing$iphonesentiment) # kknn accuracy 0.4884 kappa 0.2889

confusionMatrix(testPredc5.0, testing$iphonesentiment)
confusionMatrix(testPredrf, testing$iphonesentiment) 
confusionMatrix(testPredsvm, testing$iphonesentiment)
confusionMatrix(testPredkknn, testing$iphonesentiment)

# COR modeling preprocessing
iphoneCOR$iphonesentiment <- as.factor(iphoneCOR$iphonesentiment)
str(iphoneCOR)

set.seed(123)
iphoneSampleCOR <- iphoneCOR[sample(1:nrow(iphoneCOR), 4500, replace=FALSE),]

inTrainingCOR <- createDataPartition(iphoneSampleCOR$iphonesentiment, p = 0.70, list = FALSE)
trainingCOR <- iphoneSampleCOR[inTrainingCOR,]
testingCOR <- iphoneSampleCOR[-inTrainingCOR,]

# COR modeling - c5.0
c5.0FitCOR <- train(iphonesentiment~., data = trainingCOR, method = 'C5.0', trControl = fitControl, tuneLength = 5)

c5.0FitCOR # model = rules, winnow = FALSE, trials = 1, accuracy 0.6463, kappa 0.2333 ~less than 1min

# COR modeling - rf
rfFitCOR <- train(iphonesentiment~., data = trainingCOR, method = 'rf', trControl = fitControl, tuneLength = 5)

rfFitCOR # mtry 14, accuracy 0.6552, kappa 0.2613 ~1min

# COR predict
testPredc5.0COR <- predict(c5.0FitCOR, testingCOR)
testPredrfCOR <- predict(rfFitCOR, testingCOR)

postResample(testPredc5.0COR, testingCOR$iphonesentiment) # c5.0 accuracy 0.6577 kappa 0.2641
postResample(testPredrfCOR, testingCOR$iphonesentiment) # rf accuracy 0.6585 kappa 0.2679

confusionMatrix(testPredc5.0COR, testingCOR$iphonesentiment)
confusionMatrix(testPredrfCOR, testingCOR$iphonesentiment) 

# NZV modeling preprocessing
set.seed(123)
iphoneSampleNZV <- iphoneNZV[sample(1:nrow(iphoneNZV), 4500, replace=FALSE),]

inTrainingNZV <- createDataPartition(iphoneSampleNZV$iphonesentiment, p = 0.70, list = FALSE)
trainingNZV <- iphoneSampleNZV[inTrainingNZV,]
testingNZV <- iphoneSampleNZV[-inTrainingNZV,]

# NZV modeling - c5.0
c5.0FitNZV <- train(iphonesentiment~., data = trainingNZV, method = 'C5.0', trControl = fitControl, tuneLength = 5)

c5.0FitNZV # model = rules, winnow = FALSE, trials = 1, accuracy 0.7367, kappa 0.4738 ~less than 1min

# NZV modeling - rf
rfFitNZV <- train(iphonesentiment~., data = trainingNZV, method = 'rf', trControl = fitControl, tuneLength = 5)

rfFitNZV # mtry 2, accuracy 0.7415, kappa 0.4812 ~1min

# NZV predict
testPredc5.0NZV <- predict(c5.0FitNZV, testingNZV)
testPredrfNZV <- predict(rfFitNZV, testingNZV)

postResample(testPredc5.0NZV, testingNZV$iphonesentiment) # c5.0 accuracy 0.7609 kappa 0.5297
postResample(testPredrfNZV, testingNZV$iphonesentiment) # rf accuracy 0.7661 kappa 0.5386

confusionMatrix(testPredc5.0NZV, testingNZV$iphonesentiment)
confusionMatrix(testPredrfNZV, testingNZV$iphonesentiment) 

# RFE modeling preprocessing
set.seed(123)
iphoneSampleRFE <- iphoneRFE[sample(1:nrow(iphoneRFE), 4500, replace=FALSE),]

inTrainingRFE <- createDataPartition(iphoneSampleRFE$iphonesentiment, p = 0.70, list = FALSE)
trainingRFE <- iphoneSampleRFE[inTrainingRFE,]
testingRFE <- iphoneSampleRFE[-inTrainingRFE,]

# RFE modeling - c5.0
c5.0FitRFE <- train(iphonesentiment~., data = trainingRFE, method = 'C5.0', trControl = fitControl, tuneLength = 5)

c5.0FitRFE # model = rules, winnow = TRUE, trials = 1, accuracy 0.7522, kappa 0.5120 ~less than 1min

# RFE modeling - rf
rfFitRFE <- train(iphonesentiment~., data = trainingRFE, method = 'rf', trControl = fitControl, tuneLength = 5)

rfFitRFE # mtry 6, accuracy 0.7573, kappa 0.5255 ~1min

# RFE predict
testPredc5.0RFE <- predict(c5.0FitRFE, testingRFE)
testPredrfRFE <- predict(rfFitRFE, testingRFE)

postResample(testPredc5.0RFE, testingRFE$iphonesentiment) # c5.0 accuracy 0.7847 kappa 0.5814
postResample(testPredrfRFE, testingRFE$iphonesentiment) # rf accuracy 0.7780 kappa 0.5743

confusionMatrix(testPredc5.0RFE, testingRFE$iphonesentiment)
confusionMatrix(testPredrfRFE, testingRFE$iphonesentiment)

# import large matrix
iphoneLargeMatrix <- read.csv("iphoneLargeMatrix.csv")
iphoneLargeRFE <- subset(iphoneLargeMatrix, select = c(iphone, samsunggalaxy, googleandroid, iphonedisunc, iphonedispos,
                                                       iphonedisneg, htcphone, iphoneperpos, iphonecamneg, ios, sonyxperia,
                                                       iphoneperunc, iphonecamunc, iphoneperneg, htcperpos, iphonecampos, 
                                                       htccampos, htcperneg, iphonesentiment))
# predict large matrix
iphoneSentimentPre <- predict(c5.0FitRFE, iphoneLargeRFE)

iphoneSentimentPre

summary(iphoneSentimentPre) # 0 18436, 1 0, 2 761, 3 723, 4 8, 5 5147
