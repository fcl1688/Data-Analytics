# install.packages("RMariaDB")
# installed.packages('dplyr') solved issues for "One or more of the packages that will be updated by installation are currently loaded."

# import
library(RMariaDB)
library(dplyr)
library(lubridate)
library(caret)

# create database connection
con = dbConnect(MariaDB(), user='deepAnalytics', password='Sqltask1234!', dbname="dataanalytics2018", 
                host="data-analytics-2018.cbrosir2cswx.us-east-1.rds.amazonaws.com")

# show the tables contained in the database
dbListTables(con) # "iris" "yr_2006" "yr_2007" "yr_2008" "yr_2009" "yr_2010"

# list attributes contained in a table
dbListFields(con, 'iris') # "id" "SepalLengthCm" "SepalWidthCm"  "PetalLengthCm" "PetalWidthCm"  "Species"
dbListFields(con, 'yr_2006') # 10 features

# download all attributes from a table
irisAll <- dbGetQuery(con, "SELECT * FROM iris")

# download specific attribute from a table
irisSelect <- dbGetQuery(con, "SELECT SepalLengthCm, SepalWidthCm FROM iris")
Y2006 <- dbGetQuery(con, 'SELECT Date, Time, Sub_metering_1, Sub_metering_2, Sub_metering_3 From yr_2006')
Y2007 <- dbGetQuery(con, 'SELECT Date, Time, Sub_metering_1, Sub_metering_2, Sub_metering_3 From yr_2007')
Y2008 <- dbGetQuery(con, 'SELECT Date, Time, Sub_metering_1, Sub_metering_2, Sub_metering_3 From yr_2008')
Y2009 <- dbGetQuery(con, 'SELECT Date, Time, Sub_metering_1, Sub_metering_2, Sub_metering_3 From yr_2009')
Y2010 <- dbGetQuery(con, 'SELECT Date, Time, Sub_metering_1, Sub_metering_2, Sub_metering_3 From yr_2010')

# investigate 2006
str(Y2006)
summary(Y2006)
head(Y2006) # 12.16
tail(Y2006) # 12.31

# investigate 2007
str(Y2007)
summary(Y2007)
head(Y2007) # 1.1
tail(Y2007) # 12.31

# investigate 2008
str(Y2008)
summary(Y2008)
head(Y2008) # 1.1
tail(Y2008) # 12.31

# investigate 2009
str(Y2009)
summary(Y2009)
head(Y2009) # 1.1
tail(Y2009) # 12.31

# investigate 2010
str(Y2010)
summary(Y2010)
head(Y2010) # 1.1
tail(Y2010) # 11.26

# combine tables
Y0709 <- bind_rows(Y2007, Y2008, Y2009)

str(Y0709)
summary(Y0709)
head(Y0709) # 070101
tail(Y0709) # 091231

# combine attributes
Y0709 <- cbind(Y0709, paste(Y0709$Date, Y0709$Time), stringsAsFactors = FALSE)

# change column's name
colnames(Y0709)[6] <- 'DateTime'

# move DateTime attribute within the dataset
Y0709 <- Y0709[,c(ncol(Y0709), 1:(ncol(Y0709)-1))]
head(Y0709)

# change chr to POSIXct
Y0709$DateTime <- as.POSIXct(Y0709$DateTime, "%Y/%m/%d %H:%M:%S") # warning: unknown timezone

# add time zone
attr(Y0709$DateTime, 'tzone') <- 'GMT'
str(Y0709)

# create new feature 'year' in the dataset
Y0709$year <- year(Y0709$DateTime)

# quarter, month, week, day, hour and minute
Y0709$quarter <- quarter(Y0709$DateTime)
Y0709$month <- month(Y0709$DateTime)
Y0709$week <- week(Y0709$DateTime)
Y0709$day <- day(Y0709$DateTime)
Y0709$hour <- hour(Y0709$DateTime)
Y0709$minute <- minute(Y0709$DateTime)

head(Y0709)
tail(Y0709)

summary(Y0709$Sub_metering_1)
summary(Y0709$Sub_metering_2)
summary(Y0709$Sub_metering_3)

# remove(Y0610)