# install
# use install.packages('packageName') when there are missing packages

# import packages
library(arules)
library(arulesViz)

# import data
transData <- read.transactions('ElectronidexTransactions2017/ElectronidexTransactions2017.csv', 
                               format = 'basket', sep = ',', rm.duplicates = TRUE)

# know the data
inspect(transData) # show all transactions
inspect(transData[9834])
inspect(transData[200:203])

length(transData) # show # of transactions

size(transData) # # of items per transactions

LIST(transData) # list the items for each transactions

itemLabels(transData) # list all items in the data

# visualization
itemFrequencyPlot(transData)
itemFrequencyPlot(transData, type = 'absolute', topN = 20) # absolue = count, relative = percentile
itemFrequencyPlot(transData, type = 'absolute', topN = 10)

image(transData)
image(transData[1:300, 1:125]) # [x,y]
image(transData[1:100, 1:20]) # x = items, y = transactions

image(sample(transData, 200)) #  create sample that contains a random set of transactions

# apriori
rule1 <- apriori(transData, parameter = list(supp = 0.1, conf = 0.8)) 
inspect(rule1) # 0

rule2 <- apriori(transData, parameter = list(supp = 0.05, conf = 0.8))
inspect(rule2) # 0

rule3 <- apriori(transData, parameter = list(supp = 0.015, conf = 0.8))
inspect(rule3) # 0

rule4 <- apriori(transData, parameter = list(supp = 0.2, conf = 0.8)) 
inspect(rule4) # 0

rule5 <- apriori(transData, parameter = list(supp = 0.7, conf = 0.8)) 
inspect(rule5) # 0

rule6 <- apriori(transData, parameter = list(supp = 0.1, conf = 0.5)) 
inspect(rule6) # 0

rule7 <- apriori(transData, parameter = list(supp = 0.1, conf = 0.65)) 
inspect(rule7) # 0

rule8 <- apriori(transData, parameter = list(supp = 0.05, conf = 0.65)) 
inspect(rule8) # 0

rule9 <- apriori(transData, parameter = list(supp = 0.025, conf = 0.65))
inspect(rule9) # 0

rule10 <- apriori(transData, parameter = list(supp = 0.015, conf = 0.5))
inspect(rule10) # 5

rule11 <- apriori(transData, parameter = list(supp = 0.1, conf = 0.7)) 
inspect(rule11) # 0

rule12 <- apriori(transData, parameter = list(supp = 0.1, conf = 0.5)) 
inspect(rule12) # 0

rule13 <- apriori(transData, parameter = list(supp = 0.015, conf = 0.55))
inspect(rule13) # 2
summary(rule13)

rule14 <- apriori(transData, parameter = list(supp = 0.015, conf = 0.45))
inspect(rule14) # 12
inspect(rule14[4]) # see rule no.4
summary(rule14)

rule15 <- apriori(transData, parameter = list(supp = 0.015, conf = 0.4))
inspect(rule15) # 30

rule16 <- apriori(transData, parameter = list(supp = 0.015, conf = 0.5))
inspect(rule16) # 5

rule17 <- apriori(transData, parameter = list(supp = 0.02, conf = 0.55))
inspect(rule17) # 0

# rule 14 chosen
inspect(sort(rule14, by = c('lift', 'conf')))
inspect(sort(rule16, by = c('lift', 'conf')))
# {Dell Desktop, ViewSonic Monitor}            => {HP Laptop}
# {iMac, ViewSonic Monitor}                    => {HP Laptop}
# {Lenovo Desktop Computer, ViewSonic Monitor} => {iMac} 
# {Acer Desktop, HP Laptop}                    => {iMac}
# {Dell Desktop, Lenovo Desktop Computer}      => {iMac}

# look for specific products in the rule
itemRule1 <- subset(rule14, items %in% 'Dell Desktop')
inspect(itemRule1) # 3

itemRule2 <- subset(rule14, items %in% 'iMac')
inspect(itemRule2) # 11

is.redundant(rule14) # check redundancy, result = FALSE

# visualization
plot(rule14[1:12], method = 'graph')
plot(rule14)

